//
//  TimeViewController.swift
//  WifiConnectC
//
//  Created by Sasidhar Pasupuleti on 4/2/18.
//  Copyright © 2018 Sasidhar. All rights reserved.
//

import UIKit

class setDeviceTimeViewController: UIViewController {
    
    @IBOutlet weak var dayText: UITextField!
    @IBOutlet weak var hourText: UITextField!
    @IBOutlet weak var minText: UITextField!
    @IBOutlet weak var messageLabel: UILabel!
    //@IBOutlet weak var dayText: UITextField!
    //@IBOutlet weak var hourText: UITextField!
    //@IBOutlet weak var minText: UITextField!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    //day=1&hours=1&minutes=47&seconds=23
    var dayp=""
    var day=""
    var hourp=""
    var hour=""
    var minp=""
    var min=""
    var secp=""
    var sec=""
    var mon=""
    var dayMon=""
    var daym=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //dayText.delegate=self as? UITextFieldDelegate
        //hourText.delegate=self as? UITextFieldDelegate
        //minText.delegate=self as? UITextFieldDelegate
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func setTime(_ sender: UIButton) {
    
  //  @IBAction func setTime(_ sender: UIButton) {
        
        // grab the selected date from the date picker
        let chosenDate = self.datePicker.date
        
        // create an NSDateFormatter
        let formatterForMonth = DateFormatter()
        formatterForMonth.dateFormat = "MM"
        
        // grab the day and create a message
        let printMonth = formatterForMonth.string(from: chosenDate)
        //let resultMonth = printMonth
        print("Month:" + printMonth)
        
    
        // create an NSDateFormatter
        let formatterForDate = DateFormatter()
        formatterForDate.dateFormat = "dd"
        
        // grab the day and create a message
        let printDate = formatterForDate.string(from: chosenDate)
        //let resultDate = printDate
        print("Date:" + printDate)
        
        
        
        
        // create an NSDateFormatter
        let formatterForHour = DateFormatter()
        formatterForHour.dateFormat = "hh"
        
        // grab the day and create a message
        let printHour = formatterForHour.string(from: chosenDate)
        //let resultHour = printHour
        print("Hour:" + printHour)
        
        
        // create an NSDateFormatter
        let formatterForMinute = DateFormatter()
        formatterForMinute.dateFormat = "mm"
        
        // grab the day and create a message
        let printMinute = formatterForMinute.string(from: chosenDate)
        //let resultMinute = printMinute
        print("Minute:" + printMinute)
        
        
        
        
        
        
        
        
        
        
        
        dayp = "day="
        day =  printDate
        daym = "&mon="
        dayMon = printMonth
        hourp = "&hours="
        hour = printHour
        minp = "&minutes="
        min = printMinute
        secp = "&seconds="
        sec = "0"
        
        data_request("http://172.20.10.4/inittime")
    }
    
    func data_request(_ url:String)
    {
        let url:NSURL = NSURL(string: url)!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        
        let  finalstr = dayp+day+hourp+hour+minp+min+daym+dayMon
        let paramString = finalstr
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let url1 = URL(string: "http://172.20.10.4/inittime")
        _ = URLRequest(url: url1!)
        
        let task = session.dataTask(with: request as URLRequest) {
            (
            data, response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else {
                print("error")
                return
            }
            
            if let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            {
                print(dataString)
            }
        }
        messageLabel.text = "Device time is set"
        
        task.resume()
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}//class end

extension setDeviceTimeViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

