//
//  tableNextViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/22/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import UIKit

class tableNextViewController: UIViewController {

    
    var hero:HeroStats?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let userID = hero?.userid
         let deviceID = hero?.deviceid
        let userName = UserDefaults.standard.value(forKey: "UserName") as! String
        print("userID is: "+userID!+" deviceID is: "+deviceID!+" userName is: "+userName)
        UserDefaults.standard.setValue(userID, forKey: "UserID")
        UserDefaults.standard.setValue(deviceID, forKey: "DeviceID")
        UserDefaults.standard.synchronize()
        self.performSegue(withIdentifier: "middleToTabbar", sender: self)
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.performSegue(withIdentifier: "middleToTabbar", sender: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
