//
//  dummyViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/14/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import UIKit

class dummyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidAppear(_ animated: Bool) {
        let key = UserDefaults.standard.bool(forKey: "key")
        if(!key)
        {
            self.performSegue(withIdentifier: "dummyToLogin", sender: self)
        }
    }

    @IBAction func dummyButton(_ sender: UIButton) {
        
        UserDefaults.standard.set(false, forKey: "key")
        UserDefaults.standard.synchronize()
        
        self.performSegue(withIdentifier: "dummyToLogin", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
