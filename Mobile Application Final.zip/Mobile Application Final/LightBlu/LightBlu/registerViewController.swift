//
//  registerViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/14/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import UIKit
import WebKit


class registerViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
   
    @IBOutlet weak var RGBWebView: WKWebView!
    
    
    @IBAction func backButton(_ sender: Any) {
        
        performSegue(withIdentifier: "registerToBack", sender: self)
        
    }
    
    @IBAction func registerButton(_ sender: UIButton) {
      /*
        let request = NSMutableURLRequest(url: NSURL(string: "http://dcm.uhcl.edu/caps18g6/insertuser.php")! as URL)
        request.httpMethod = "POST"
        
        let postString = "pass=123&name=\(usernameTextField.text!)&password=\(passwordTextField.text!)"
        
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, response, error in
            
            if error != nil {
                print("error=\(error)")
                return
            }
            
            print("response = \(response)")
            
            let responseString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            print("responseString = \(responseString)")
            
            
            
        }
        task.resume()
        */
        
        
        let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/registeruser.php?pass=123&name="+usernameTextField.text!+"&password="+passwordTextField.text!)
        let request2 = URLRequest(url: url!)
        RGBWebView.load(request2)
   /*
        if url != nil {
            let task = URLSession.shared.dataTask(with: url! as URL, completionHandler: { (data, response, error) -> Void in
                print(data as Any)
                
                if error == nil {
                    
                    let urlContent = NSString(data: data!, encoding: String.Encoding.ascii.rawValue) as NSString!
                    
                    print(urlContent as Any)
                }
            })
            task.resume()
        }
      */
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
