//
//  HeroStats.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/21/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import Foundation

struct HeroStats:Decodable {
    
    let userid: String
    let deviceid: String
}
