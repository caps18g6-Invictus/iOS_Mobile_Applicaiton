//
//  TimeViewController.swift
//  WifiConnectC
//
//  Created by Sasidhar Pasupuleti on 4/2/18.
//  Copyright © 2018 Sasidhar. All rights reserved.
//

import UIKit
import WebKit

class TimeViewController: UIViewController {
    
    @IBOutlet weak var deviceLabel: UILabel!
    /*@IBOutlet weak var dayText: UITextField!
    @IBOutlet weak var hourText: UITextField!
    @IBOutlet weak var minText: UITextField!*/
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var endDatePicker: UIDatePicker!
    //@IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var mellageLabel: UILabel!
    @IBOutlet weak var dayText: UITextField!
    
    @IBOutlet weak var hourText: UITextField!
    
    @IBOutlet weak var minText: UITextField!
    //day=1&hours=1&minutes=47&seconds=23
    
    
    @IBOutlet weak var offWebView: WKWebView!
    @IBOutlet weak var onWebView: WKWebView!
    
    
    var userID = UserDefaults.standard.value(forKey: "UserID") as! String
    var deviceID = UserDefaults.standard.value(forKey: "DeviceID") as! String
    let userName = UserDefaults.standard.value(forKey: "UserName") as! String
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //dayText.delegate=self as? UITextFieldDelegate
        //hourText.delegate=self as? UITextFieldDelegate
        //minText.delegate=self as? UITextFieldDelegate
        // Do any additional setup after loading the view.
        deviceLabel.text = "Device: "+deviceID
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func setTime(_ sender: Any) {
    
    // @IBAction func setTime(_ sender: UIButton) {
        
        
        
        // grab the selected date from the date picker
        let chosenDate = self.datePicker.date
        
        // create an NSDateFormatter
        let formatterForMonth = DateFormatter()
        formatterForMonth.dateFormat = "MM"
        
        // grab the day and create a message
        let printMonth = formatterForMonth.string(from: chosenDate)
        //let resultMonth = printMonth
        print("Month:" + printMonth)
        
        
        // create an NSDateFormatter
        let formatterForDate = DateFormatter()
        formatterForDate.dateFormat = "dd"
        
        // grab the day and create a message
        let printDate = formatterForDate.string(from: chosenDate)
        //let resultDate = printDate
        print("Date:" + printDate)
        
        
        
        
        // create an NSDateFormatter
        let formatterForHour = DateFormatter()
        formatterForHour.dateFormat = "HH"
        
        // grab the day and create a message
        let printHour = formatterForHour.string(from: chosenDate)
        //let resultHour = printHour
        print("Hour:" + printHour)
        
        
        // create an NSDateFormatter
        let formatterForMinute = DateFormatter()
        formatterForMinute.dateFormat = "mm"
        
        // grab the day and create a message
        let printMinute = formatterForMinute.string(from: chosenDate)
        //let resultMinute = printMinute
        print("Minute:" + printMinute)
        
        
        
        
        //end date picker:
        
        // grab the selected date from the date picker
        let endchosenDate = self.endDatePicker.date
        
        // create an NSDateFormatter
        let endformatterForMonth = DateFormatter()
        endformatterForMonth.dateFormat = "MM"
        
        // grab the day and create a message
        let endprintMonth = endformatterForMonth.string(from: endchosenDate)
        //let resultMonth = printMonth
        print("Month:" + endprintMonth)
        
        
        // create an NSDateFormatter
        let endformatterForDate = DateFormatter()
        endformatterForDate.dateFormat = "dd"
        
        // grab the day and create a message
        let endprintDate = endformatterForDate.string(from: endchosenDate)
        //let resultDate = printDate
        print("Date:" + endprintDate)
        
        
        
        
        // create an NSDateFormatter
        let endformatterForHour = DateFormatter()
        endformatterForHour.dateFormat = "HH"
        
        // grab the day and create a message
        let endprintHour = endformatterForHour.string(from: endchosenDate)
        //let resultHour = printHour
        print("Hour:" + endprintHour)
        
        
        // create an NSDateFormatter
        let endformatterForMinute = DateFormatter()
        endformatterForMinute.dateFormat = "mm"
        
        // grab the day and create a message
        let endprintMinute = endformatterForMinute.string(from: endchosenDate)
        //let resultMinute = printMinute
        print("Minute:" + endprintMinute)
        
        
        
        //http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/schedtest.php?status=1&dates=2018-04-09 13:34:00&trun=0&pass=123
        //http://ec2-54-206-123-245.ap-southeast-2.compute.amazonaws.com/test.php?cid=2&intensity=0&year=2018&day="+printDate+"&month="+printMonth+"&hours="+printHour+"&minutes="+printMinute+"&seconds=30&red=0&green=0&blue=0&pass=123&trun=0
        //http://ec2-54-206-123-245.ap-southeast-2.compute.amazonaws.com/test.php?cid=2&intensity=0&year=2018&day="+endprintDate+"&month="+endprintMonth+"&hours="+endprintHour+"&minutes="+endprintMinute+"&seconds=30&red=0&green=0&blue=0&pass=123&trun=0
        
        
        let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usersched.php?status=1&dates=2018-"+printMonth+"-"+printDate+"%20"+printHour+":"+printMinute+":00&trun=0&pass=123&username="+userName+"&devid="+deviceID)
        let request = URLRequest(url: url!)
        onWebView.load(request)
        
        
        let url1 = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usersched.php?status=0&dates=2018-"+endprintMonth+"-"+endprintDate+"%20"+endprintHour+":"+endprintMinute+":00&trun=0&pass=123&username="+userName+"&devid="+deviceID)
        let request1 = URLRequest(url: url1!)
        offWebView.load(request1)
        
        
        
        
      mellageLabel.text = "Schedule is Set"
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}//class end

extension TimeViewController : UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

