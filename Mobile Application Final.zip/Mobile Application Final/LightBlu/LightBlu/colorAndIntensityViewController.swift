//
//  colorAndIntensityViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/8/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import UIKit
import WebKit

class colorAndIntensityViewController: UIViewController {

    @IBOutlet weak var deviceLabel: UILabel!
    @IBOutlet weak var redLabel: UILabel!
    @IBOutlet weak var greenLabel: UILabel!
    @IBOutlet weak var blueLabel: UILabel!
    
    @IBOutlet weak var intensityLabel: UILabel!
    
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var lightWebView: WKWebView!
    
    @IBOutlet weak var RGBWebView: WKWebView!
    
    var val4 = 0
    var rval4 = 0
    var gval4 = 0
    var bval4 = 0
    
    var userID = UserDefaults.standard.value(forKey: "UserID") as! String
    var deviceID = UserDefaults.standard.value(forKey: "DeviceID") as! String
    let userName = UserDefaults.standard.value(forKey: "UserName") as! String
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        deviceLabel.text = "Device: "+deviceID
        // Do any additional setup after loading the view.
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func lightSwitch(_ sender: UISwitch) {
        
        if (sender.isOn == true)
        {
            let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usercommand.php?cid=1&intensity=0&pass=123&trun=0&username="+userName+"&devid="+deviceID)
            let request = URLRequest(url: url!)
            lightWebView.load(request)
        }
        else
        {
            
            let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usercommand.php?cid=1&intensity=1023&pass=123&trun=0&username="+userName+"&devid="+deviceID)
            let request = URLRequest(url: url!)
            lightWebView.load(request)
            
           
            
            
        }
        
    }
    

    @IBAction func redSlider(_ sender: UISlider) {
        
        let rval2 = sender.value
        let rval3 = rval2*1023
        rval4 = Int(1023-rval3)
        
        redLabel.text = String(Int(rval3))
        
    }
   
    @IBAction func greenSlider(_ sender: UISlider) {
    
        
        let gval2 = sender.value
        let gval3 = gval2*1023
        gval4 = Int(1023-gval3)
        
        greenLabel.text = String(Int(gval3))
        
        
    }
    
    @IBAction func blueSlider(_ sender: UISlider) {
    
        
        
        let bval2 = sender.value
        let bval3 = bval2*1023
        bval4 = Int(1023-bval3)
        
        blueLabel.text = String(Int(bval3))
    }
    
    @IBAction func intensitySlider(_ sender: UISlider) {
        
        
        let val2 = sender.value
        let val3 = val2*1023
        val4 = Int(1023-val3)
        
        intensityLabel.text = String(Int(val3))
    }
    
    @IBAction func setColor(_ sender: UIButton) {
        
        
        
        let url2 = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usercommand.php?cid=2&intensity=0&year=2018&day=8&month=4&hours=2&minutes=34&seconds=56&red="+String(Int(rval4))+"&green="+String(Int(gval4))+"&blue="+String(Int(bval4))+"&pass=123&trun=0&username="+userName+"&devid="+deviceID)
        let request2 = URLRequest(url: url2!)
        RGBWebView.load(request2)
        
        
    }
    @IBAction func setColorAndIntensity(_ sender: UIButton) {
        
        //cid1....intesity
        //cid2-----RGB
        let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usercommand.php?cid=1&intensity="+String(Int(val4))+"&year=2018&day=8&month=4&hours=2&minutes=34&seconds=56&red=0&green=0&blue=0&pass=123&trun=0&username="+userName+"&devid="+deviceID)
        let request = URLRequest(url: url!)
        webView.load(request)
        
        //http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usercommand.php?cid=1&intensity="+String(Int(val4))+"&year=2018&day=8&month=4&hours=2&minutes=34&seconds=56&red="+redLabel+"&green="+greenLabel+"&blue="+blueLabel+"&pass=123&trun=0&username="+userName+"&devid="+deviceID
        
        //http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/usercommand.php?cid=2&intensity=400&year=2018&day=8&month=4&hours=2&minutes=34&seconds=56&red=322&green=344&blue=224&pass=123&trun=0
        
        
        //print("hellOOOOO")
        
        
        
        
        
        
    }
    
  /*
    func data_request(_ url:String)
    {
        let url:NSURL = NSURL(string: url)!
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url as URL)
        request.httpMethod = "POST"
        
        let  finalstr = redLabel.text! + greenLabel.text! + blueLabel.text! + intensityLabel.text!
        let paramString = finalstr
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let url1 = URL(string: "http://172.20.10.4/alarm")
        _ = URLRequest(url: url1!)
        
        let task = session.dataTask(with: request as URLRequest) {
            (
            data, response, error) in
            
            guard let _:NSData = data as NSData?, let _:URLResponse = response, error == nil else {
                print("error")
                return
            }
            
            if let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
            {
                print(dataString)
            }
        }
        
        
        task.resume()
        
    }
 */
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
