//
//  settingsViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/6/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import UIKit

class settingsViewController: UIViewController {

    @IBOutlet weak var webView: UIWebView!
    
    
    @IBOutlet weak var intensityDisplayLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func lightSwitch(_ sender: UISwitch) {
       
        if (sender.isOn == true)
        {
            let url = URL(string: "http://172.20.10.4/ledon")
            let request = URLRequest(url: url!)
            webView.loadRequest(request)
            
        }
        else
        {
            let url = URL(string: "http://172.20.10.4/ledoff")
            let request = URLRequest(url: url!)
            webView.loadRequest(request)
            
        }
       
    }
    
    @IBAction func slider(_ sender: UISlider) {
        
        
        //let val = intensityDisplayLabel.text
        let val2 = sender.value
        let val3 = val2*100
        
        intensityDisplayLabel.text = String(Int(val3)) //String(sender.value)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
