//
//  qrReaderViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/9/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import UIKit
import AVFoundation
import WebKit

class qrReaderViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    //@IBOutlet weak var square: UIImageView!
    let userID = UserDefaults.standard.value(forKey: "UserID") as! String
    
    var onSave: ((_ data: String) -> ())?
     
    
    @IBOutlet weak var RGBWebView: WKWebView!
    
    @IBOutlet weak var square: UIImageView!
    var video = AVCaptureVideoPreviewLayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Creating session
        let session = AVCaptureSession()
        
        //Define capture devcie
        let captureDevice = AVCaptureDevice.default(for: AVMediaType.video)
        
        do
        {
            let input = try AVCaptureDeviceInput(device: captureDevice!)
            session.addInput(input)
        }
        catch
        {
            print ("ERROR")
        }
        
        let output = AVCaptureMetadataOutput()
        session.addOutput(output)
        
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        output.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        video = AVCaptureVideoPreviewLayer(session: session)
        video.frame = view.layer.bounds
        view.layer.addSublayer(video)
        
        self.view.bringSubview(toFront: square)
        
        session.startRunning()
    }
    
    func metadataOutput(_ captureOutput: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        
        if metadataObjects != nil && metadataObjects.count != 0
        {
            if let object = metadataObjects[0] as? AVMetadataMachineReadableCodeObject
            {
                if object.type == AVMetadataObject.ObjectType.qr
                {
                    let alert = UIAlertController(title: "QR Code", message: object.stringValue, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Retake", style: .default, handler: nil))
                    
                    alert.addAction(UIAlertAction(title: "Copy", style: .default, handler: { (nil) in
                        UIPasteboard.general.string = object.stringValue
                        let st : String  = object.stringValue!
                        
                        print("text:" + st)
                        
                        
                        self.onSave?(st)
                        
                        let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/getud.php?trun=0&userid="+self.userID+"&devid="+st)
                        let request = URLRequest(url: url!)
                        self.RGBWebView.load(request)
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    }))
                    
                    present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    

   

}
