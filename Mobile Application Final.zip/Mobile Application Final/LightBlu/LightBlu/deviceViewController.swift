//
//  deviceViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/9/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//
import Foundation
import UIKit
import WebKit



class deviceViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    
    
    var heroes = [HeroStats]()
    
    
    
    var myIndex = 0
    
    var deviceName = String()
    var userNAME = String()
    var uID = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.reloadData()
        downloadJSON {
            self.tableView.reloadData()
            print("Successful")
        }
        
    }
    
   
    func downloadJSON(completed: @escaping () -> ()) {
       // let deviceUserID = "5"
        let deviceUserID = UserDefaults.standard.value(forKey: "UserID") as! String
        let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/getud.php?trun=1&userid=" + deviceUserID)
        print("userid  :::: "+deviceUserID)
        
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error == nil {
                do {
                    self.heroes = try JSONDecoder().decode([HeroStats].self, from: data!)
                    
                    DispatchQueue.main.async {
                        completed()
                    }
                }
            catch
                {
                    print("JSON Error")
                }
            }
        }.resume()
    }
    
    
    
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addDeviceSegue" {
            let popup = segue.destination as! qrReaderViewController
            popup.onSave = onSave
            
        }
        
        
        if segue.identifier == "dummyToLogin" {
            let popup2 = segue.destination as! loginViewController
            popup2.uName = uName
            
            let popup3 = segue.destination as! loginViewController
            popup3.uid = uid
            
        }
        
        
       if segue.identifier == "deviceToTabBar" {
           if let destination = segue.destination as? tableNextViewController {
                destination.hero = heroes[(tableView.indexPathForSelectedRow?.row)!]
                
            }
        }
    }
    
    
    func onSave(_ data: String) -> () {
        deviceName = data
        print("THE DEVICE IS:::::" + deviceName)
        
        UserDefaults.standard.set(deviceName, forKey: "myList")
        //let newDevices = UserDefaults.standard.object(forKey: "myList") as? String
        
        
        downloadJSON {
            self.tableView.reloadData()
            print("Successful")
        }
        
    }
    
    
    func uid(_ data: String) -> () {
        uID = data
        print("uid:::: " + uID)
        UserDefaults.standard.setValue(uID, forKey: "UserID")
        UserDefaults.standard.synchronize()
        
        
        downloadJSON {
            self.tableView.reloadData()
            print("Successful")
        }
        
    }
    
    
    func uName(_ data: String) -> () {
       userNAME = data
        print("username is ::::" + userNAME)
        UserDefaults.standard.setValue(userNAME, forKey: "UserName")
        UserDefaults.standard.synchronize()
        
        
        downloadJSON {
            self.tableView.reloadData()
            print("Successful")
        }
        
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
      return heroes.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: nil)
        
        cell.textLabel?.text = heroes[indexPath.row].deviceid.capitalized
          return(cell)
        
    }
    
    public func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
       /*
        if editingStyle == .delete {
            list.remove(at: indexPath.row)
            
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
        }
 */
    }
    
    
    

   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        let key = UserDefaults.standard.bool(forKey: "key")
        if(!key)
        {
            self.performSegue(withIdentifier: "dummyToLogin", sender: self)
        }
       
        downloadJSON {
            self.tableView.reloadData()
            print("Successful")
        }
        
      tableView.reloadData()
    }
    
    @IBAction func dummyButton(_ sender: UIBarButtonItem) {
   
        
        UserDefaults.standard.set(false, forKey: "key")
        UserDefaults.standard.synchronize()
        
        self.performSegue(withIdentifier: "dummyToLogin", sender: self)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        
        performSegue(withIdentifier: "deviceToTabBar", sender: self)
    }
    
   
    
}
