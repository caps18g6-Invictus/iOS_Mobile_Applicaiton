//
//  loginViewController.swift
//  LightBlu
//
//  Created by Alla Sai Poorna, Rohith Raj Reddy on 4/13/18.
//  Copyright © 2018 Reddipalli, Sai Lochan Reddy. All rights reserved.
//

import UIKit



class loginViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var validationLabel: UILabel!
    
    
    var flag = 0
    
    
   
    var uName: ((_ data: String) -> ())?
    
    var uid: ((_ data: String) -> ())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        
       
        
    }

    @IBAction func loginButton(_ sender: UIButton) {
        
        //let result1 = "Valid User"
       // var result2 = String()
      //  var urlContent: String?
        
        
        if let title = usernameTextField.text, !title.isEmpty {
        
        
        if let title1 = passwordTextField.text, !title1.isEmpty
        {
        
        
        let url1 = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/validuser.php?pass=123&name="+usernameTextField.text!+"&password="+passwordTextField.text!)
        
        
        
        
        //let url1 = NSURL(string: "http://dcm.uhcl.edu/caps18g6/validateuser.php?pass=123&name=raghu&password=1234")
        
        if url1 != nil {
            let task1 = URLSession.shared.dataTask(with: url1! as URL) { (data1, response, error) in
                
                if error != nil
                {
                    print("ERROR")
                }
                else
                {
                    if let content1 = data1
                    {
                        do
                        {
                            let myJson1 = try JSONSerialization.jsonObject(with: data1!, options: .mutableContainers) as? NSDictionary
                            //print(myJson)
                            if let parseJSON1 = myJson1
                            {
                                
                                var resultid:String = parseJSON1["id"] as! String
                                print("IDresult: \(resultid)")
                                
                                
                                if (resultid != nil && resultid != "0")
                                {
                                    print("id is in resultid")
                                    
                                    //self.performSegue(withIdentifier: "loginSuccess", sender: self)
                                    self.uid?(resultid)
                                    
                                    self.dismiss(animated: true, completion: nil)
                                    
                                }
                                else if (resultid == "0")
                                {
                                    self.flag = 1
                                    
                                }
                                
                                
                                
                            }
                            
                        }
                        catch
                        {
                            
                        }
                    }
                }
            }
            task1.resume()
        }
        
        
        
        
        if flag == 1
        {
            
            self.validationLabel.text = "Enter Valid Username and Password"
            flag = 0
            }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        //"http://dcm.uhcl.edu/caps18g6/validateuser.php?pass=123&name=raghu&password=1234"
        //http://api.fixer.io/latest
        //http://dcm.uhcl.edu/caps18g6/validateuser.php?pass=123&name="+usernameTextField.text!+"&password="+passwordTextField.text!
        let url = URL(string: "http://ec2-13-211-121-155.ap-southeast-2.compute.amazonaws.com/validateuser.php?pass=123&name="+usernameTextField.text!+"&password="+passwordTextField.text!)
       
       self.uName?(usernameTextField.text!)
        
        
        //let url1 = NSURL(string: "http://dcm.uhcl.edu/caps18g6/validateuser.php?pass=123&name=raghu&password=1234")
   
        if url != nil {
            let task = URLSession.shared.dataTask(with: url! as URL) { (data, response, error) in

                if error != nil
                {
                    print("ERROR")
                }
                else
                {
                    if let content = data
                    {
                        do
                        {
                            let myJson = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                            //print(myJson)
                            if let parseJSON = myJson
                            {
                                
                                var result:String = parseJSON["valid"] as! String
                                print("result: \(result)")
                                
                                
                                if(result == "true")
                                {
                                    print("result is true")
        
                                    //self.performSegue(withIdentifier: "loginSuccess", sender: self)
                                    UserDefaults.standard.set(true, forKey: "key")
                                    UserDefaults.standard.synchronize();
                                    
                                    self.dismiss(animated: true, completion: nil)
                    
                                }
                                
                                else
                                {
                                    self.flag = 1
                                    //self.validationLabel.text = "Enter Valid Username and Password"
                                }
                                
                                
                                
                            }
    
                        }
                        catch
                        {
                            
                        }
                    }
                }
                }
            task.resume()
        }
            if flag == 1
            {
                
                self.validationLabel.text = "Enter Valid Username and Password"
                flag = 0
            }
        
      
         }
        else
        {
            validationLabel.text = "Enter Valid Username and Password"
            }
            
        }
        
        else
        {
            validationLabel.text = "Enter Valid Username and Password"
        }
    }
        
        
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}
